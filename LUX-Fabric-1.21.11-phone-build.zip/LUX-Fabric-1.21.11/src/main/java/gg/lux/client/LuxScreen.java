package gg.lux.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class LuxScreen extends Screen {
    private int tab = 0;
    private static final String[] TABS = {"Modules", "Crystal", "Anchor", "Visuals", "Config"};

    public LuxScreen() {
        super(Text.literal("LUX Client"));
    }

    @Override
    protected void init() {
        // Drawn and handled manually to keep the GUI lightweight and dependency-free.
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);

        int panelW = Math.min(720, this.width - 36);
        int panelH = Math.min(430, this.height - 36);
        int x = (this.width - panelW) / 2;
        int y = (this.height - panelH) / 2;

        ctx.fill(x - 1, y - 1, x + panelW + 1, y + panelH + 1, 0xFF8B5CF6);
        ctx.fill(x, y, x + panelW, y + panelH, 0xF0181722);
        ctx.fill(x, y, x + panelW, y + 42, 0xFF211D30);
        ctx.drawText(this.textRenderer, "L U X", x + 18, y + 13, 0xFFC4A7FF, false);
        ctx.drawText(this.textRenderer, "CLIENT  •  1.21.11", x + 90, y + 15, 0xFFAAA5B8, false);

        int tabX = x + 16;
        for (int i = 0; i < TABS.length; i++) {
            int bx = tabX + i * 105;
            int color = (tab == i) ? 0xFF8B5CF6 : 0xFF302B3D;
            ctx.fill(bx, y + 55, bx + 96, y + 80, color);
            ctx.drawCenteredTextWithShadow(this.textRenderer, TABS[i], bx + 48, y + 63, 0xFFFFFFFF);
        }

        int left = x + 20;
        int top = y + 102;
        ctx.drawText(this.textRenderer, "LUX  /  " + TABS[tab].toUpperCase(), left, top, 0xFFC4A7FF, false);

        switch (tab) {
            case 0 -> renderModules(ctx, left, top + 28);
            case 1 -> renderCrystal(ctx, left, top + 28);
            case 2 -> renderAnchor(ctx, left, top + 28);
            case 3 -> renderVisuals(ctx, left, top + 28);
            case 4 -> renderConfig(ctx, left, top + 28);
        }

        ctx.drawText(this.textRenderer,
            "RIGHT SHIFT  Close GUI     •     F8  Stream Mode     •     Click options to toggle",
            x + 18, y + panelH - 22, 0xFFAAA5B8, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderModules(DrawContext ctx, int x, int y) {
        line(ctx, x, y, "Practice", "Client-side practice utilities and preferences");
        line(ctx, x, y + 28, "Combat automation", "Not included in this build");
        line(ctx, x, y + 56, "Anti-cheat bypass", "Not included");
        line(ctx, x, y + 84, "Stream Mode", LuxClient.CONFIG.streamMode ? "ON" : "OFF");
    }

    private void renderCrystal(DrawContext ctx, int x, int y) {
        line(ctx, x, y, "Crystal timing profile", on(LuxClient.CONFIG.crystalTimingProfile));
        line(ctx, x, y + 30, "Place delay", LuxClient.CONFIG.crystalPlaceDelayMs + " ms   (click: +20)");
        line(ctx, x, y + 60, "Break delay", LuxClient.CONFIG.crystalBreakDelayMs + " ms   (click: +20)");
        line(ctx, x, y + 100, "These are saved timing preferences only; no automatic combat actions.");
    }

    private void renderAnchor(DrawContext ctx, int x, int y) {
        line(ctx, x, y, "Anchor timing profile", on(LuxClient.CONFIG.anchorTimingProfile));
        line(ctx, x, y + 30, "Place delay", LuxClient.CONFIG.anchorPlaceDelayMs + " ms   (click: +20)");
        line(ctx, x, y + 60, "Charge delay", LuxClient.CONFIG.anchorChargeDelayMs + " ms   (click: +20)");
        line(ctx, x, y + 90, "Detonate delay", LuxClient.CONFIG.anchorDetonateDelayMs + " ms   (click: +20)");
        line(ctx, x, y + 130, "Saved preferences only; no automated placement or detonation.");
    }

    private void renderVisuals(DrawContext ctx, int x, int y) {
        line(ctx, x, y, "Module list", on(LuxClient.CONFIG.showModuleList));
        line(ctx, x, y + 30, "Coordinates preference", on(LuxClient.CONFIG.showCoordinates));
        line(ctx, x, y + 60, "Player ESP preference", on(LuxClient.CONFIG.playerEspPreference));
        line(ctx, x, y + 90, "Tracers preference", on(LuxClient.CONFIG.tracersPreference));
        line(ctx, x, y + 120, "Nametags preference", on(LuxClient.CONFIG.nametagsPreference));
        line(ctx, x, y + 150, "Loaded-chunk overlay preference", on(LuxClient.CONFIG.chunkOverlayPreference));
        line(ctx, x, y + 185, "Visual overlays are preference switches; hidden server data is not read.");
    }

    private void renderConfig(DrawContext ctx, int x, int y) {
        line(ctx, x, y, "Config file", "config/lux.json");
        line(ctx, x, y + 32, "Save config", "Click here");
        line(ctx, x, y + 64, "Reset defaults", "Click here");
        line(ctx, x, y + 100, "F8 toggles Stream Mode. Stream Mode does not hide the GUI from capture software.");
    }

    private void line(DrawContext ctx, int x, int y, String label, String value) {
        ctx.fill(x - 5, y - 5, x + 660, y + 19, 0x553B354B);
        ctx.drawText(this.textRenderer, label, x + 5, y + 2, 0xFFE8E3F2, false);
        if (value != null) {
            int w = this.textRenderer.getWidth(value);
            ctx.drawText(this.textRenderer, value, x + 650 - w, y + 2, 0xFFC4A7FF, false);
        }
    }

    private String on(boolean value) {
        return value ? "ON" : "OFF";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelW = Math.min(720, this.width - 36);
        int panelH = Math.min(430, this.height - 36);
        int x = (this.width - panelW) / 2;
        int y = (this.height - panelH) / 2;

        if (mouseY >= y + 55 && mouseY <= y + 80) {
            int index = ((int) mouseX - (x + 16)) / 105;
            if (index >= 0 && index < TABS.length) tab = index;
            return true;
        }

        int contentX = x + 15;
        int contentY = y + 130;
        if (mouseX >= contentX && mouseX <= x + panelW - 15 && mouseY >= contentY) {
            int row = ((int) mouseY - contentY) / 30;
            switch (tab) {
                case 0 -> {
                    if (row == 3) LuxClient.CONFIG.streamMode = !LuxClient.CONFIG.streamMode;
                }
                case 1 -> {
                    if (row == 0) LuxClient.CONFIG.crystalTimingProfile = !LuxClient.CONFIG.crystalTimingProfile;
                    if (row == 1) LuxClient.CONFIG.crystalPlaceDelayMs = nextDelay(LuxClient.CONFIG.crystalPlaceDelayMs);
                    if (row == 2) LuxClient.CONFIG.crystalBreakDelayMs = nextDelay(LuxClient.CONFIG.crystalBreakDelayMs);
                }
                case 2 -> {
                    if (row == 0) LuxClient.CONFIG.anchorTimingProfile = !LuxClient.CONFIG.anchorTimingProfile;
                    if (row == 1) LuxClient.CONFIG.anchorPlaceDelayMs = nextDelay(LuxClient.CONFIG.anchorPlaceDelayMs);
                    if (row == 2) LuxClient.CONFIG.anchorChargeDelayMs = nextDelay(LuxClient.CONFIG.anchorChargeDelayMs);
                    if (row == 3) LuxClient.CONFIG.anchorDetonateDelayMs = nextDelay(LuxClient.CONFIG.anchorDetonateDelayMs);
                }
                case 3 -> {
                    if (row == 0) LuxClient.CONFIG.showModuleList = !LuxClient.CONFIG.showModuleList;
                    if (row == 1) LuxClient.CONFIG.showCoordinates = !LuxClient.CONFIG.showCoordinates;
                    if (row == 2) LuxClient.CONFIG.playerEspPreference = !LuxClient.CONFIG.playerEspPreference;
                    if (row == 3) LuxClient.CONFIG.tracersPreference = !LuxClient.CONFIG.tracersPreference;
                    if (row == 4) LuxClient.CONFIG.nametagsPreference = !LuxClient.CONFIG.nametagsPreference;
                    if (row == 5) LuxClient.CONFIG.chunkOverlayPreference = !LuxClient.CONFIG.chunkOverlayPreference;
                }
                case 4 -> {
                    if (row == 1) LuxConfig.save(LuxClient.CONFIG);
                    if (row == 2) {
                        LuxClient.CONFIG.streamMode = false;
                        LuxClient.CONFIG.showModuleList = true;
                        LuxClient.CONFIG.showCoordinates = false;
                        LuxClient.CONFIG.crystalTimingProfile = false;
                        LuxClient.CONFIG.crystalPlaceDelayMs = 120;
                        LuxClient.CONFIG.crystalBreakDelayMs = 120;
                        LuxClient.CONFIG.anchorTimingProfile = false;
                        LuxClient.CONFIG.anchorPlaceDelayMs = 120;
                        LuxClient.CONFIG.anchorChargeDelayMs = 120;
                        LuxClient.CONFIG.anchorDetonateDelayMs = 120;
                        LuxClient.CONFIG.playerEspPreference = false;
                        LuxClient.CONFIG.tracersPreference = false;
                        LuxClient.CONFIG.nametagsPreference = false;
                        LuxClient.CONFIG.chunkOverlayPreference = false;
                    }
                }
            }
            LuxConfig.save(LuxClient.CONFIG);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private int nextDelay(int current) {
        return current >= 1000 ? 20 : current + 20;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
