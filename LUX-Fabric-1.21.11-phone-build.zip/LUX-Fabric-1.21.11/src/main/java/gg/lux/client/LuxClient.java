package gg.lux.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class LuxClient implements ClientModInitializer {
    public static final LuxConfig CONFIG = new LuxConfig();
    private boolean rightShiftWasDown;
    private boolean f8WasDown;

    @Override
    public void onInitializeClient() {
        LuxConfig.loadInto(CONFIG);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() == null) return;

            boolean rightShiftDown = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT);
            if (rightShiftDown && !rightShiftWasDown) {
                if (client.currentScreen instanceof LuxScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new LuxScreen());
                }
            }
            rightShiftWasDown = rightShiftDown;

            boolean f8Down = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_F8);
            if (f8Down && !f8WasDown) {
                CONFIG.streamMode = !CONFIG.streamMode;
                LuxConfig.save(CONFIG);
                if (client.player != null) {
                    client.player.sendMessage(net.minecraft.text.Text.literal(
                        "LUX Stream Mode: " + (CONFIG.streamMode ? "ON" : "OFF")), true);
                }
            }
            f8WasDown = f8Down;
        });
    }
}
