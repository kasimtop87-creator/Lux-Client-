package gg.lux.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class LuxConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = Path.of("config", "lux.json");

    public boolean streamMode = false;
    public boolean showModuleList = true;
    public boolean showCoordinates = false;

    public boolean crystalTimingProfile = false;
    public int crystalPlaceDelayMs = 120;
    public int crystalBreakDelayMs = 120;

    public boolean anchorTimingProfile = false;
    public int anchorPlaceDelayMs = 120;
    public int anchorChargeDelayMs = 120;
    public int anchorDetonateDelayMs = 120;

    public boolean playerEspPreference = false;
    public boolean tracersPreference = false;
    public boolean nametagsPreference = false;
    public boolean chunkOverlayPreference = false;

    public static void loadInto(LuxConfig target) {
        try {
            Files.createDirectories(FILE.getParent());
            if (!Files.exists(FILE)) return;
            try (Reader reader = Files.newBufferedReader(FILE)) {
                LuxConfig loaded = GSON.fromJson(reader, LuxConfig.class);
                if (loaded != null) target.copyFrom(loaded);
            }
        } catch (Exception e) {
            System.err.println("[LUX] Config load failed: " + e.getMessage());
        }
    }

    public static void save(LuxConfig config) {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(config, writer);
            }
        } catch (Exception e) {
            System.err.println("[LUX] Config save failed: " + e.getMessage());
        }
    }

    private void copyFrom(LuxConfig other) {
        streamMode = other.streamMode;
        showModuleList = other.showModuleList;
        showCoordinates = other.showCoordinates;
        crystalTimingProfile = other.crystalTimingProfile;
        crystalPlaceDelayMs = other.crystalPlaceDelayMs;
        crystalBreakDelayMs = other.crystalBreakDelayMs;
        anchorTimingProfile = other.anchorTimingProfile;
        anchorPlaceDelayMs = other.anchorPlaceDelayMs;
        anchorChargeDelayMs = other.anchorChargeDelayMs;
        anchorDetonateDelayMs = other.anchorDetonateDelayMs;
        playerEspPreference = other.playerEspPreference;
        tracersPreference = other.tracersPreference;
        nametagsPreference = other.nametagsPreference;
        chunkOverlayPreference = other.chunkOverlayPreference;
    }
}
