# LUX Client — Fabric 1.21.11

This is a Gradle/Loom **source project** for a client-side Fabric mod. It is not a precompiled JAR.

## Requirements
- Java JDK 21
- Gradle 8.14+ (or a compatible Gradle installation)
- Internet access on first build so Gradle can download Minecraft, Fabric and Loom dependencies

## Build the mod
Open a terminal in this folder and run:

Windows:
```bat
gradle build
```

macOS/Linux:
```bash
gradle build
```

The compiled mod will be at:
`build/libs/lux-client-0.2.0.jar`

Copy that JAR into your Modrinth instance's `mods` folder. The Modrinth profile must use Minecraft 1.21.11, Fabric Loader, and Java 21.

## Controls
- Right Shift: open/close LUX ClickGUI
- F8: toggle Stream Mode state
- Click the GUI tabs to change preferences and saved delay values
- Config is stored at `.minecraft/config/lux.json`

## Scope / honest feature status
The GUI, keybind handling, and JSON config persistence are implemented. Crystal/anchor delay values are currently **timing profiles only**; this build does not automate combat actions. The visual entries are preferences only and do not yet render ESP or inspect hidden server-side chunk data. Stream Mode is a state toggle; it does not conceal the client from OBS or other capture software.

Combat automation, anti-cheat evasion, and hidden-data scanning are not included. This keeps the starter suitable as a client-side GUI/config foundation without claiming unfinished modules work.


## Build from a phone using GitHub Actions
This project includes `.github/workflows/build.yml`. If you upload the extracted project files to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build LUX Fabric Mod**.
3. Tap **Run workflow** (or push to `main`).
4. When the run finishes, open it and download the artifact named `lux-client-fabric-1.21.11`.
5. The artifact contains the compiled JAR(s) from `build/libs`.

This cloud build requires a GitHub account and a successful Gradle dependency resolution. It does not turn the unfinished placeholder preferences into combat automation.
